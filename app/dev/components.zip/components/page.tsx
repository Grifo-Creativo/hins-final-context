// app/dev/components/page.tsx
"use client"

import { GenerationSparkline } from "@/components/charts/GenerationSparkline"
import { ParkEnergyBarChart } from "@/components/charts/ParkEnergyBarChart"
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { CardWithContent } from "@/components/ui/card-with-content"
import { HinsTooltip } from "@/components/ui/hins-tooltip"
import { IconBadge } from "@/components/ui/icon-badge"
import { KpiPrimary } from "@/components/ui/kpi-primary"
import { KpiSecondary } from "@/components/ui/kpi-secondary"
import { PeriodSelectorLocal } from "@/components/ui/period-selector"
import { SectionHeader } from "@/components/ui/section-header"
import { SoftBadge } from "@/components/ui/soft-badge"
import { StatList, type StatListItem } from "@/components/ui/stat-list"
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table"
import { TabsForBlocks } from "@/components/ui/tabs-for-blocks"
import {
  parkEnergyBarChartConfig,
  generationSparklineConfig,
} from "@/data/chart-config"
import { generationSparklinePoints } from "@/data/gdd-performance-mock"
import Link from "next/link"
import {
  InfoIcon,
  MoreHorizontal,
  SunIcon,
  ZapIcon,
} from "lucide-react"

const BAR_DEMO = [
  { label: "Nov 25", generated: 120 },
  { label: "Dic 25", generated: 140 },
  { label: "Ene 26", generated: 130 },
  { label: "Feb 26", generated: 155 },
  { label: "Mar 26", generated: 168 },
  { label: "Abr 26", generated: 180 },
]

const STAT_LIST_DEMO: StatListItem[] = [
  { name: "Potencia utilizada", value: "NN kWh" },
  { name: "Fecha de alta", value: "NN" },
  { name: "Nombre del responsable", value: "NN" },
  { name: "Teléfono de contacto", value: "NN" },
  { name: "Ahorro en Emisiones", value: "3.47" },
]

function Showcase({
  title,
  file,
  children,
}: {
  title: string
  file: string
  children: React.ReactNode
}) {
  return (
    <section className="scroll-mt-8 rounded-xl border border-border bg-card p-6 shadow-sm">
      <div className="mb-4 flex flex-col gap-1 border-b border-border pb-4">
        <h2 className="text-lg font-semibold text-foreground">{title}</h2>
        <p className="font-mono text-xs text-muted-foreground">{file}</p>
      </div>
      <div className="flex flex-col gap-4">{children}</div>
    </section>
  )
}

export default function DevComponentsPage() {
  const sparkForKpi = generationSparklinePoints.map((p) => ({ value: p.value }))

  return (
    <div className="min-h-screen bg-background">
      <div className="mx-auto max-w-5xl px-6 py-10">
        <header className="mb-10 flex flex-col gap-4 border-b border-border pb-8 sm:flex-row sm:items-end sm:justify-between">
          <div>
            <p className="text-xs font-medium uppercase tracking-wide text-muted-foreground">
              HINS · Dev
            </p>
            <h1 className="mt-1 text-3xl font-bold text-foreground">
              Galería de componentes
            </h1>
            <p className="mt-2 max-w-xl text-sm text-muted-foreground">
              Vista rápida de los bloques de{" "}
              <code className="rounded bg-muted px-1 py-0.5 text-xs">context/components.md</code>{" "}
              implementados en el repo.
            </p>
          </div>
          <Button variant="outline" size="sm" asChild>
            <Link href="/">Volver al inicio</Link>
          </Button>
        </header>

        <div className="flex flex-col gap-10">
          <Showcase title="TabsForBlocks" file="components/ui/tabs-for-blocks.tsx">
            <div className="h-10 max-w-md">
              <TabsForBlocks
                tabs={[
                  { value: "1M", label: "1M" },
                  { value: "3M", label: "3M" },
                  { value: "6M", label: "6M" },
                ]}
                defaultValue="6M"
              />
            </div>
          </Showcase>

          <Showcase title="Card (shadcn)" file="components/ui/card.tsx">
            <Card className="max-w-md py-0 ring-0">
              <CardHeader className="border-b border-border">
                <CardTitle>Título de card</CardTitle>
                <CardDescription>Descripción secundaria opcional.</CardDescription>
              </CardHeader>
              <CardContent className="p-4">
                <p className="text-sm text-muted-foreground">
                  Contenido con padding definido por el consumidor.
                </p>
              </CardContent>
            </Card>
          </Showcase>

          <Showcase title="IconBadge" file="components/ui/icon-badge.tsx">
            <div className="flex items-center gap-4">
              <IconBadge icon={ZapIcon} size="sm" />
              <IconBadge icon={SunIcon} size="lg" />
            </div>
          </Showcase>

          <Showcase title="SoftBadge" file="components/ui/soft-badge.tsx">
            <div className="flex flex-wrap gap-2">
              <SoftBadge>+12% vs mes anterior</SoftBadge>
              <SoftBadge icon={ZapIcon}>Con ícono</SoftBadge>
            </div>
          </Showcase>

          <Showcase title="KpiPrimary" file="components/ui/kpi-primary.tsx">
            <div className="max-w-md">
              <KpiPrimary
                icon={SunIcon}
                label="Energía generada (abr.)"
                value="31.0"
                unit="kWh"
                delta="+8% vs marzo"
                sparklineData={sparkForKpi}
              />
            </div>
          </Showcase>

          <Showcase title="KpiSecondary" file="components/ui/kpi-secondary.tsx">
            <div className="max-w-xs">
              <KpiSecondary
                icon={ZapIcon}
                label="Participación"
                value="25%"
                delta="Cuotaparte"
                infoTooltip={{
                  content: "Porcentaje de energía asignada al socio en el parque.",
                }}
              />
            </div>
          </Showcase>

          <Showcase title="CardWithContent" file="components/ui/card-with-content.tsx">
            <CardWithContent
              title="Bloque con tabs"
              subtitle="Subtítulo de ejemplo"
              tabs={[
                { value: "a", label: "Tab A" },
                { value: "b", label: "Tab B" },
              ]}
              defaultTab="a"
            >
              <p className="text-sm text-muted-foreground">
                Contenido del bloque (chart, tabla, etc.).
              </p>
            </CardWithContent>
          </Showcase>

          <Showcase title="StatList" file="components/ui/stat-list.tsx">
            <div className="max-w-md rounded-lg border border-border p-4">
              <StatList title="Más información del socio" items={STAT_LIST_DEMO} />
            </div>
          </Showcase>

          <Showcase title="Table" file="components/ui/table.tsx">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Columna</TableHead>
                  <TableHead className="text-right">Valor</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                <TableRow>
                  <TableCell>Fila 1</TableCell>
                  <TableCell className="text-right tabular-nums">128</TableCell>
                </TableRow>
                <TableRow>
                  <TableCell>Fila 2</TableCell>
                  <TableCell className="text-right tabular-nums">256</TableCell>
                </TableRow>
              </TableBody>
            </Table>
          </Showcase>

          <Showcase title="GenerationSparkline" file="components/charts/GenerationSparkline.tsx">
            <div className="max-w-xl rounded-lg border border-border p-4">
              <GenerationSparkline
                data={generationSparklinePoints}
                chartConfig={generationSparklineConfig}
                className="aspect-auto h-14 w-full"
              />
            </div>
          </Showcase>

          <Showcase title="ParkEnergyBarChart" file="components/charts/ParkEnergyBarChart.tsx">
            <div className="rounded-lg border border-border p-4">
              <ParkEnergyBarChart
                data={BAR_DEMO}
                chartConfig={parkEnergyBarChartConfig}
              />
            </div>
          </Showcase>

          <Showcase title="HinsTooltip" file="components/ui/hins-tooltip.tsx">
            <p className="text-sm text-foreground">
              Pasá el mouse por el ícono:{" "}
              <HinsTooltip
                trigger={<InfoIcon className="inline size-4 text-muted-foreground" />}
                content="Texto de ayuda contextual."
              />
            </p>
          </Showcase>

          <Showcase title="SectionHeader" file="components/ui/section-header.tsx">
            <SectionHeader
              title="Título de sección"
              size="md"
              action={
                <Button type="button" variant="ghost" size="icon" aria-label="Más">
                  <MoreHorizontal className="size-4" />
                </Button>
              }
            />
            <SectionHeader title="Sub-sección" size="sm" className="mt-4" />
          </Showcase>

          <Showcase title="PeriodSelector" file="components/ui/period-selector.tsx">
            <PeriodSelectorLocal defaultValue="Abril 2026" />
          </Showcase>

          <Showcase title="HinsAlert" file="components/ui/alert.tsx">
            <div className="flex flex-col gap-3">
              <Alert variant="warning">
                <AlertTitle>Advertencia</AlertTitle>
                <AlertDescription>Ejemplo variante warning.</AlertDescription>
              </Alert>
              <Alert variant="info">
                <AlertDescription>Nota informativa sin título.</AlertDescription>
              </Alert>
              <Alert variant="success">
                <AlertDescription>Operación completada.</AlertDescription>
              </Alert>
              <Alert variant="error">
                <AlertTitle>Error</AlertTitle>
                <AlertDescription>No se pudieron cargar los datos.</AlertDescription>
              </Alert>
            </div>
          </Showcase>

          <section className="rounded-xl border border-dashed border-muted-foreground/40 bg-muted/30 p-6">
            <h2 className="text-lg font-semibold text-foreground">
              Documentados en components.md, sin archivo aún
            </h2>
            <ul className="mt-3 list-inside list-disc text-sm text-muted-foreground">
              <li>
                <span className="font-mono text-foreground">PageHeader</span> —{" "}
                <span className="font-mono">components/ui/page-header.tsx</span>
              </li>
            </ul>
          </section>
        </div>
      </div>
    </div>
  )
}
